import React from "react";
import '../App.css';
import image from "../images/unnamed.jpg"

// import Login from "./Login"
// import Signup from "./Signup"
// import Dash from "./Dashboard"
// import Post from "./Post"
// import Button from "@mui/material/Button";
// import AppBar from '@mui/material/AppBar';
// import Box from '@mui/material/Box';
// import Toolbar from '@mui/material/Toolbar';
// import Typography from '@mui/material/Typography';

// import IconButton from '@mui/material/IconButton';
// import MenuIcon from '@mui/icons-material/Menu';

// import {
//   BrowserRouter as Router,
//   Switch,
//   Route,
//   Link
// } from "react-router-dom";



function Dashboard() {
    return (
      <div>




        <br/>
<img src={image} class="card-img-top" alt="..." height="300px" className="image1"/>

      </div>

        );
      }
      export default Dashboard;
     